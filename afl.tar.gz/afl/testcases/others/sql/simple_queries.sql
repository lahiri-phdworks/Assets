create table t1(one smallint);
insert into t1 values(1);
select * from t1;
