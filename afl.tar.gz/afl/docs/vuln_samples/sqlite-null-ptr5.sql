select e.*,0 from(s,(L))e;
