#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
    char arg[1000], temp1;
    int temp;
    size_t i;
    FILE *fp;
    fp = fopen(argv[1],"r");
    if (fp == NULL){
        printf("Please provide input file\n");
        exit(0);
    }
    for(i=0; i < strlen(argv[2]);i++){
        if(argv[2][i+1] == 'd'){
            fscanf(fp,"%d",&temp);
            printf("%d\n",temp);
        }
        else if(argv[2][i+1] == 'c'){
            fscanf(fp,"%c",&temp1);
            printf("%c\n",temp1);
        }
        else{
            fscanf(fp,"%s",arg);
            printf("%s\n",arg);
        
        }
        i++;
    }
    return 0;
}
